package cpsc2150.mortgages;

public class Mortgage extends AbsMortgage implements IMortgage {
    /**
     * Created by zbroome and hdmcgee on 10/09/2019.
     *
     * @Invariants
     * Payment = (mpr * principal) / (1-(1+mpr)^ -numberOfPayments)
     * 0 <= mpr <= 1
     * 0 < debtToIncomeRatio
     * MIN_YEARS * 12 <= numberOfPayments <= MAX_YEARS * 12
     * 0 < principal
     * 0 <= percentDown < 1
     * apr = mpr * 12
     *
     * Correspondence Payment = monthlyPayment
     * Correspondence Rate = mpr
     * Correspondence Customer = customer
     * Correspondence DebtToIncomeRatio = deptToIncomeRatio
     * Correspondence Principle = principle
     * Correspondence NumberOfPayments = numberOfPayments
     * Correspondence PercentDown = percentDown
     */

    private double payment;
    private double rate;
    private Customer customer;
    private double debtToIncomeRatio;
    private double principal;
    private int numberOfPayments;
    private double percentDown;

    private double c;
    private double downpayment;
    private int numberOfYears;

    private double apr;

    /**
     *
     * @param c cost of the home
     * @param dp down payment on the home
     * @param numberOfYears number of years the loan is for
     * @param customer the customer taking out the loan
     * @pre c > 0, c > dp >= 0, MAX_YEARS >= numberOfYear >= MIN_YEARS, customer is intialized and contains valid private fields
     * @post [rate is calculated and payment is calculated, a valid object is created]
     */
    Mortgage(double c, double dp, int numberOfYears, ICustomer customer) {
        this.c = c;
        downpayment = dp;
        this.numberOfYears = numberOfYears;

        //Principle
        principal = c - downpayment;

        //Payment
        //payment = (cost of the home - down payment) / numberOfYears, then divide by 12 to get monthly
        double paymentAYear = (c - downpayment)/numberOfYears;


        //Rate
        //calculating apr
        apr = BASERATE;
        if(numberOfYears < 30)
            apr = apr + GOODRATEADD;
        else
            apr = apr + NORMALRATEADD;

        percentDown = downpayment / c;
        if(percentDown < PREFERRED_PERCENT_DOWN)
            apr = apr + GOODRATEADD;

        int creditScore = customer.getCreditScore();

        if(creditScore < BADCREDIT)
            apr = apr + VERYBADRATEADD;
        else if(creditScore >= BADCREDIT && creditScore < FAIRCREDIT)
            apr = apr + BADRATEADD;
        else if(creditScore >= FAIRCREDIT && creditScore < GOODCREDIT)
            apr = apr + NORMALRATEADD;
        else if(creditScore >= GOODCREDIT && creditScore < GREATCREDIT)
            apr = apr + GOODRATEADD;
        //dont need 750 <=score<= 850 since it adds 0

        rate = apr/12;

        //customer
        this.customer = new Customer(customer.getMonthlyDebtPayments(), customer.getIncome(), customer.getCreditScore(), customer.getName());

        //numberOfPayments
        numberOfPayments = 12 * numberOfYears;

        payment = (rate * principal) / (1 - Math.pow((1+rate),-numberOfPayments));

        //customer.getMonthlyDebtPayments() + Payment + (Rate*Principal)
        double monthlyDebtPayment = customer.getMonthlyDebtPayments() + payment;

        double monthlyIncome = customer.getIncome()/12;

        debtToIncomeRatio = monthlyDebtPayment / monthlyIncome;
    }
    public boolean loanApproved() {
        if((rate*12 < RATETOOHIGH) && (percentDown >= MIN_PERCENT_DOWN) && (debtToIncomeRatio <= DTOITOOHIGH)){
            return true;
        }
        return false;
    }

    public double getPayment() {
        return payment;
    }
    public double getRate() {
        return rate*12;

    }
    public double getPrincipal() {
        return principal;
    }
    public int getYears() {
        return numberOfYears;
    }
}
