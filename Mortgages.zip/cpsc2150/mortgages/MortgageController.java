package cpsc2150.mortgages;

public class MortgageController implements IMortgageController{

    private IMortgageView view;

    MortgageController(IMortgageView v) {
        view = v;
    }
    public void submitApplication() {
        String name;
        double yearlyIncome;
        double monthlyDebtPayments;
        int creditScore;
        double rate;
        double payment;
        int years;
        double downPayment;
        double houseCost;
        double principle;

        ICustomer customer;
        IMortgage mortgage;

        do { // new customer
            name = view.getName(); // get name
            do { // get yearly income
                yearlyIncome = view.getYearlyIncome();
                if(yearlyIncome <= 0) // validate
                    view.printToUser("Income must be greater than 0");
            }while(yearlyIncome <= 0);
            do { // get monthly debt payments
                monthlyDebtPayments = view.getMonthlyDebt();
                if(monthlyDebtPayments < 0)
                    view.printToUser("Debt must be greater than or equal to 0");
            }while(monthlyDebtPayments < 0);
            do { // get credit score
                creditScore = view.getCreditScore();
                if(creditScore < 0 || creditScore >= 850)
                    view.printToUser("Credit Score must be greater than or equal to 0 and less than 850");
            }while(creditScore < 0 || creditScore >= 850);

            customer = new Customer(monthlyDebtPayments, yearlyIncome, creditScore, name);
            do { // new mortgage
                do { // get house cost
                    houseCost = view.getHouseCost();
                    if (houseCost < 0)
                        view.printToUser("Cost must be greater than 0");
                } while(houseCost < 0);
                do { // get down mayment
                    downPayment = view.getDownPayment();
                    if (downPayment < 0 || downPayment >= houseCost)
                        view.printToUser("Down Payment must be greater than 0 and less than the cost of the house");
                }while(downPayment < 0 || downPayment >= houseCost);
                do {
                    years = view.getYears();
                    if(years <= 0)
                        view.printToUser("Years must be greater than 0");
                }while(years <= 0);

                mortgage = new Mortgage(houseCost, downPayment, years, customer);
                payment = mortgage.getPayment();
                rate = mortgage.getRate();
                principle = mortgage.getPrincipal();

                //print customer info
                view.printToUser("Name: " + name);
                view.printToUser("Income: $" + yearlyIncome);
                view.printToUser("Credit Score: " + creditScore);
                view.printToUser(" Monthly Debt: $" + monthlyDebtPayments);
                //print mortgage info
                view.printToUser("Mortgage info:");
                view.printToUser("Principle Amount: $" + principle);
                view.printToUser("Interest Rate: " + rate*100 + "%");
                view.printToUser("Term: " + years);
                view.printToUser("Monthly Payment: $" + payment + "\n");

            }while(view.getAnotherMortgage());
        }while(view.getAnotherCustomer());
    }
}
