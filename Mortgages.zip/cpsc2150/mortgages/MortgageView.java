package cpsc2150.mortgages;

import java.util.Scanner;

public class MortgageView implements IMortgageView {
    private Scanner input = new Scanner(System.in);
    private IMortgageController controller;

    public void setController(IMortgageController c){
        controller = c;
    }

    public double getHouseCost() {
        System.out.println("How much does the house cost?");
        double cost = Double.parseDouble(input.nextLine());

        return cost;
    }

    public double getDownPayment() {
        System.out.println("How much is the down payment?");
        double down = Double.parseDouble(input.nextLine());

        return down;
    }

    public int getYears() {
        System.out.println("How many years?");
        int years = Integer.parseInt(input.nextLine());

        return years;
    }

    public double getMonthlyDebt() {
        System.out.println("How much are your monthly debt payments?");
        double monthlydebt = Double.parseDouble(input.nextLine());

        return monthlydebt;
    }

    public double getYearlyIncome() {
        System.out.println("How much is your yearly income?");
        double income = Double.parseDouble(input.nextLine());

        return income;
    }

    public int getCreditScore() {
        System.out.println("What is your credit score?");
        int score = Integer.parseInt(input.nextLine());

        return score;
    }

    public String getName() {
        System.out.println("What's your name?");
        String g = input.nextLine();

        return g;
    }

    public void printToUser(String s) {
        System.out.println(s);
    }

    public void displayPayment(double p) {
        Double w = p;
        System.out.println("$" + w.toString());
    }

    public void displayRate(double p) {
        Double w = p;

        System.out.println("$" + w.toString());
    }

    public void displayApproved(boolean a) {
        Boolean b = a;
        System.out.println(b.toString());
    }

    public boolean getAnotherMortgage() {
        System.out.println("Would you like to apply for another mortgage? y/n");
        String answer = input.nextLine();

        boolean boolanswer = false;
        if(answer.equals("y")) {
            boolanswer = true;
        }

        return boolanswer;
    }

    public boolean getAnotherCustomer() {
        System.out.println("Would you like to consider another customer? y/n");
        String answer = input.nextLine();

        boolean boolanswer = false;
        if(answer.equals("y")) {
            boolanswer = true;
        }

        return boolanswer;
    }
}
